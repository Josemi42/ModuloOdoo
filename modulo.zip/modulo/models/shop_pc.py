# -*- coding: utf-8 -*-
from dataclasses import field
from odoo import models, fields, api
from pkg_resources import PathMetadata
from odoo.exceptions import UserError
from odoo.tools.translate import _


class shoppc(models.Model):
    _name = 'shop.shop'
    _description = 'Reacondicionado Pc'

    name = fields.Char('Title', required=True)
    procesador = fields.Text('CPU')
    placa_base = fields.Text('Mother board')
    memoria_ram = fields.Text('RAM')
    date_release = fields.Date('Release Date')
    grafica = fields.Text('GPU')
    fuente_alimentacion = fields.Text('PSU')
    num_discos = fields.Integer('Numbes of hard disk')
    ssd = fields.Text('Disk SSD')
    hdd = fields.Text('Disk HDD')
    author_ids = fields.Many2many('res.partner', string='Authors')
    esPortatil = fields.Boolean('Is Laptop')
    caja = fields.Text('Box')
    image = fields.Char('Image')
    category_id = fields.Many2one('shop.pc.category', string='Category')
    state = fields.Selection([
        ('unavalible', 'Unavalible'),
        ('avalible', 'Avalible')
    ], 'State', default="unavalible")

    @api.model
    def is_allowed_transition(self, old_state, new_state):
        allowed = [('unavalible', 'available'),
                   ('available', 'unavalible')]
        return (old_state, new_state) in allowed

    def change_state(self, new_state):
        for pc in self:
            if pc.is_allowed_transition(pc.state, new_state):
                pc.state = new_state
            else:
                message = _('Moving from %s to %s is not allowd') % (pc.state, new_state)
                raise UserError(message)
